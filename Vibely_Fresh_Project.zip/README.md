# Vibely — Fresh Android Project

Fresh Android/Kotlin project for phone-to-GitHub Actions builds.
Features: local profile editing, name/username search, discover profiles, connect, and report/block UI.
This build does not yet connect the Android app to Supabase.
