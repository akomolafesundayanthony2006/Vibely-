package com.vibely.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val people = listOf(
        Person("Maya", "@maya", "Music • Movies • Art"),
        Person("Daniel", "@daniel", "Football • Gaming • Coding"),
        Person("Tobi", "@tobi", "Anime • Photography • Books"),
        Person("Zara", "@zara", "Travel • Dance • Comedy")
    )
    private var myName = "Your Name"
    private var myUsername = "@username"
    private var myBio = "Tell people a little about you."
    private val prefs by lazy { getSharedPreferences("vibely", Context.MODE_PRIVATE) }

    data class Person(val name:String, val username:String, val interests:String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        myName = prefs.getString("name", myName) ?: myName
        myUsername = prefs.getString("username", myUsername) ?: myUsername
        myBio = prefs.getString("bio", myBio) ?: myBio
        showHome()
    }

    private fun base(title:String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18,18,26))
            setPadding(24, 28, 24, 16)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = TextView(this).apply {
            text = title
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, 1)
        }
        bar.addView(t, LinearLayout.LayoutParams(0, 60, 1f))
        val profile = Button(this).apply {
            text = "Profile"
            setOnClickListener { showProfile() }
        }
        bar.addView(profile, LinearLayout.LayoutParams(-2, 55))
        root.addView(bar)
        content = root
        setContentView(root)
        return root
    }

    private fun text(s:String, size:Float=16f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); setPadding(4,10,4,10)
    }

    private fun button(label:String, action:()->Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun showHome() {
        val root = base("Vibely")
        root.addView(text("Find people and connect through shared interests.", 17f))
        val search = EditText(this).apply {
            hint = "🔎 Search people by name or username"
            setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 60))
        root.addView(button("Search") { searchPeople(search.text.toString()) })
        root.addView(text("Discover", 22f))
        people.take(3).forEach { p ->
            root.addView(button("${p.name}  ${p.username}\n${p.interests}") { showPerson(p) })
        }
        root.addView(button("My Profile") { showProfile() })
    }

    private fun searchPeople(q:String) {
        val root = base("Search")
        root.addView(text("Results for: ${if(q.isBlank()) "everyone" else q}", 17f))
        val matches = if(q.isBlank()) people else people.filter {
            it.name.contains(q, true) || it.username.contains(q, true)
        }
        if(matches.isEmpty()) root.addView(text("No people found."))
        matches.forEach { p -> root.addView(button("${p.name}  ${p.username}\n${p.interests}") { showPerson(p) }) }
        root.addView(button("← Back") { showHome() })
    }

    private fun showPerson(p:Person) {
        val root = base("Profile")
        root.addView(text("👤  ${p.name}", 25f))
        root.addView(text(p.username, 17f))
        root.addView(text(p.interests, 17f))
        root.addView(button("Connect") {
            Toast.makeText(this, "Connection request sent", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Report / Block") {
            Toast.makeText(this, "Safety options opened", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("← Back") { showHome() })
    }

    private fun showProfile() {
        val root = base("My Profile")
        root.addView(text("👤  $myName", 25f))
        root.addView(text(myUsername, 17f))
        root.addView(text(myBio, 17f))
        root.addView(button("Edit Profile") { editProfile() })
        root.addView(button("← Home") { showHome() })
    }

    private fun editProfile() {
        val root = base("Edit Profile")
        val name = EditText(this).apply { setText(myName); hint = "Display name"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val username = EditText(this).apply { setText(myUsername); hint = "Username"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val bio = EditText(this).apply { setText(myBio); hint = "Bio"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        root.addView(name, LinearLayout.LayoutParams(-1,60))
        root.addView(username, LinearLayout.LayoutParams(-1,60))
        root.addView(bio, LinearLayout.LayoutParams(-1,100))
        root.addView(button("Save Profile") {
            myName = name.text.toString().ifBlank { "Your Name" }
            myUsername = username.text.toString().ifBlank { "@username" }
            myBio = bio.text.toString().ifBlank { "Tell people a little about you." }
            prefs.edit().putString("name",myName).putString("username",myUsername).putString("bio",myBio).apply()
            showProfile()
        })
        root.addView(button("Cancel") { showProfile() })
    }
}
