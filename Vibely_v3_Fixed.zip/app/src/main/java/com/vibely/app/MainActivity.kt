package com.vibely.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity:Activity(){
    private val bg=Color.rgb(17,17,24); private val white=Color.WHITE; private val muted=Color.LTGRAY
    private val prefs by lazy{getSharedPreferences("vibely",Context.MODE_PRIVATE)}
    private var name=""; private var username=""; private var bio=""; private var interests=mutableListOf<String>()
    private data class Person(val n:String,val u:String,val i:String,val c:String)
    private val people=listOf(
        Person("Maya","@maya","Music • Movies • Art","Lagos"),
        Person("Daniel","@daniel","Football • Gaming • Coding","Ibadan"),
        Person("Tobi","@tobi","Anime • Photography • Books","Akure"),
        Person("Zara","@zara","Travel • Dance • Comedy","Benin City"),
        Person("Chris","@chris","Technology • Sports • Movies","Abeokuta")
    )
    override fun onCreate(b:Bundle?){super.onCreate(b);load();if(prefs.getBoolean("logged",false))home() else welcome()}
    private fun load(){name=prefs.getString("name","")?:"";username=prefs.getString("user","")?:"";bio=prefs.getString("bio","")?:"";interests=(prefs.getString("ints","")?:"").split("|").filter{it.isNotBlank()}.toMutableList()}
    private fun save(){prefs.edit().putString("name",name).putString("user",username).putString("bio",bio).putString("ints",interests.joinToString("|")).putBoolean("logged",true).apply()}
    private fun root(title:String,back:(()->Unit)?=null):LinearLayout{
        val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(20,24,20,12);r.setBackgroundColor(bg)
        val bar=LinearLayout(this);bar.gravity=Gravity.CENTER_VERTICAL
        if(back!=null)bar.addView(btn("‹"){back()},LinearLayout.LayoutParams(55,55))
        val t=TextView(this);t.text=title;t.textSize=27f;t.setTextColor(white);t.typeface=Typeface.DEFAULT_BOLD
        bar.addView(t,LinearLayout.LayoutParams(0,60,1f));r.addView(bar);setContentView(r);return r
    }
    private fun txt(s:String,z:Float=16f)=TextView(this).apply{text=s;textSize=z;setTextColor(white);setPadding(4,10,4,10)}
    private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()}}
    private fun field(h:String,v:String="")=EditText(this).apply{hint=h;setText(v);setTextColor(white);setHintTextColor(muted);setSingleLine(true)}
    private fun welcome(){val r=root("");val l=txt("Vibely",40f);l.gravity=Gravity.CENTER;r.addView(l,LinearLayout.LayoutParams(-1,110));val s=txt("Connect through shared interests.",18f);s.gravity=Gravity.CENTER;r.addView(s);r.addView(btn("Create account"){signup()});r.addView(btn("Log in"){login()})}
    private fun signup(){val r=root("Create account"){welcome()};val n=field("Display name");val u=field("Username");val e=field("Email");val p=field("Password");listOf(n,u,e,p).forEach{r.addView(it,LinearLayout.LayoutParams(-1,60))};r.addView(btn("Create account"){name=n.text.toString().ifBlank{"Vibely User"};username=u.text.toString().let{if(it.startsWith("@"))it else "@$it"};bio="New to Vibely 👋";interests.clear();save();interests()});r.addView(btn("Already have an account? Log in"){login()})}
    private fun login(){val r=root("Log in"){welcome()};val e=field("Email or username");val p=field("Password");r.addView(e,LinearLayout.LayoutParams(-1,60));r.addView(p,LinearLayout.LayoutParams(-1,60));r.addView(btn("Log in"){if(name.isBlank()){name="Vibely User";username="@user";bio="Welcome to Vibely";save()}else{prefs.edit().putBoolean("logged",true).apply()};home()});r.addView(txt("Demo build: account data is stored on this phone.",14f))}
    private fun home(){val r=root("Vibely");val q=field("🔎  Search people by name or username");r.addView(q,LinearLayout.LayoutParams(-1,62));r.addView(btn("Search"){search(q.text.toString())});r.addView(txt("Discover",22f));people.take(3).forEach{r.addView(person(it))};r.addView(btn("See all people"){discover()});r.addView(txt("Quick access",22f));r.addView(btn("👤 My Profile"){profile()});r.addView(btn("🤝 Connections"){connections()});r.addView(btn("💬 Messages"){messages()})}
    private fun person(p:Person)=btn("👤 ${p.n}\n${p.u}  •  ${p.i}"){personPage(p)}
    private fun search(q:String){val r=root("Search"){home()};val x=q.trim().lowercase(Locale.getDefault());val m=if(x.isBlank())people else people.filter{it.n.lowercase().contains(x)||it.u.lowercase().contains(x)};r.addView(txt(if(x.isBlank())"People on Vibely" else "Results for \"$q\"",18f));if(m.isEmpty())r.addView(txt("No matching people found."));m.forEach{r.addView(person(it))}}
    private fun discover(){val r=root("Discover"){home()};r.addView(txt("People you might connect with",18f));people.forEach{r.addView(person(it))}}
    private fun personPage(p:Person){val r=root("Profile"){home()};r.addView(txt("👤 ${p.n}",30f));r.addView(txt(p.u,18f));r.addView(txt("📍 ${p.c}",15f));r.addView(txt("Interests\n${p.i}",17f));r.addView(btn("Connect"){Toast.makeText(this,"Connection request sent",Toast.LENGTH_SHORT).show()});r.addView(btn("Report / Block"){Toast.makeText(this,"Safety options opened",Toast.LENGTH_SHORT).show()})}
    private fun profile(){load();val r=root("My Profile"){home()};r.addView(txt("👤 ${name.ifBlank{"Your Name"}}",30f));r.addView(txt(username.ifBlank{"@username"},18f));r.addView(txt(bio.ifBlank{"Tell people about yourself."},17f));r.addView(txt("Interests",20f));r.addView(txt(if(interests.isEmpty())"No interests selected yet." else interests.joinToString(" • ")));r.addView(btn("✏️ Edit Profile"){edit()});r.addView(btn("⭐ Choose Interests"){interests()});r.addView(btn("Log out"){prefs.edit().putBoolean("logged",false).apply();welcome()})}
    private fun edit(){val r=root("Edit Profile"){profile()};val n=field("Display name",name);val u=field("Username",username);val b=field("Bio",bio);listOf(n,u,b).forEach{r.addView(it,LinearLayout.LayoutParams(-1,65))};r.addView(btn("Save changes"){name=n.text.toString().ifBlank{"Vibely User"};username=u.text.toString().let{if(it.startsWith("@"))it else "@$it"};bio=b.text.toString().ifBlank{"Tell people about yourself."};save();profile()})}
    private fun interests(){
        val r=root("Your Interests"){profile()}
        r.addView(txt("Pick up to 8 interests.",17f))
        val cs=listOf("Gaming","Music","Sports","Movies","Books","Art","Technology","Comedy","Travel","Photography","Cooking","Fashion","Fitness","Anime","Football","Basketball","Coding","Nature","Dance","Writing")
        cs.forEach { c ->
            val cb=CheckBox(this)
            cb.text=c
            cb.textSize=16f
            cb.setTextColor(white)
            cb.isChecked=interests.contains(c)
            cb.setOnCheckedChangeListener { _, yes ->
                if(yes && !interests.contains(c)){
                    if(interests.size<8) interests.add(c)
                    else {
                        cb.isChecked=false
                        Toast.makeText(this,"Maximum 8 interests",Toast.LENGTH_SHORT).show()
                    }
                } else if(!yes) {
                    interests.remove(c)
                }
            }
            r.addView(cb)
        }
        r.addView(btn("Save interests"){save();profile()})
    }
    private fun connections(){val r=root("Connections"){home()};r.addView(txt("No connections yet.",18f));r.addView(btn("Find people"){discover()})}
    private fun messages(){val r=root("Messages"){home()};r.addView(txt("No messages yet.",18f));r.addView(txt("Your conversations will appear here.",16f))}
}