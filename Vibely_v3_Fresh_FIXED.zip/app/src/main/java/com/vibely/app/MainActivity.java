package com.vibely.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences p; LinearLayout root; String me="";
    String[] names={"Alex Johnson","Maya Ade","Daniel Cole","Sarah James","Chris Bello","Tobi Kay","Peace Obi","Jordan Lee"};
    String[] users={"alex","maya","daniel","sarah","chris","tobi","peace","jordan"};
    ArrayList<String> interests=new ArrayList<>();
    int d(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("vibely",0);me=p.getString("logged_user","");if(me.isEmpty())welcome();else home();}
    void setup(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(d(18),d(18),d(18),d(18));root.setBackgroundColor(Color.rgb(10,10,16));setContentView(root);}
    TextView tv(String s,int z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);t.setTypeface(Typeface.DEFAULT,bold?1:0);t.setPadding(0,d(6),0,d(6));return t;}
    EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(Color.rgb(150,150,160));e.setTextColor(Color.WHITE);e.setSingleLine();e.setPadding(d(14),0,d(14),0);e.setBackgroundColor(Color.rgb(28,28,38));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,d(50));q.setMargins(0,d(6),0,d(6));e.setLayoutParams(q);return e;}
    Button btn(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);b.setOnClickListener(l);b.setBackgroundColor(Color.rgb(91,55,170));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,d(48));q.setMargins(0,d(4),0,d(4));b.setLayoutParams(q);return b;}
    void title(String a,String b){root.addView(tv(a,27,true));if(b!=null){TextView x=tv(b,14,false);x.setTextColor(Color.LTGRAY);root.addView(x);}}
    void gap(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,d(h)));root.addView(s);}
    ScrollView scroll(LinearLayout x){ScrollView s=new ScrollView(this);s.addView(x);return s;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void welcome(){setup();root.setGravity(Gravity.CENTER_HORIZONTAL);gap(55);TextView logo=tv("Vibely",42,true);logo.setGravity(17);root.addView(logo);TextView sub=tv("Meet people. Share moments. Be yourself.",16,false);sub.setGravity(17);sub.setTextColor(Color.LTGRAY);root.addView(sub);gap(22);root.addView(btn("Create account",v->signup()));root.addView(btn("Log in",v->login()));root.addView(tv("Demo mode • information stays on this device",12,false));}
    void signup(){setup();title("Create your account","Use a display name, username and password.");EditText n=input("Display name"),u=input("Username"),pw=input("Password"),cf=input("Confirm password");pw.setInputType(129);cf.setInputType(129);root.addView(n);root.addView(u);root.addView(pw);root.addView(cf);root.addView(btn("Create account",v->{String name=n.getText().toString().trim(),user=u.getText().toString().trim().replace(" ","").toLowerCase(Locale.US),pass=pw.getText().toString();if(name.length()<2||user.length()<2||pass.length()<4){toast("Enter valid details.");return;}if(!pass.equals(cf.getText().toString())){toast("Passwords do not match.");return;}if(p.contains("pass_"+user)){toast("Username already exists.");return;}p.edit().putString("name_"+user,name).putString("pass_"+user,pass).putString("bio_"+user,"New to Vibely 👋").putString("logged_user",user).apply();me=user;home();}));root.addView(btn("Already have an account? Log in",v->login()));}
    void login(){setup();title("Welcome back","Log in to continue.");EditText u=input("Username"),pw=input("Password");pw.setInputType(129);root.addView(u);root.addView(pw);root.addView(btn("Log in",v->{String user=u.getText().toString().trim().toLowerCase(Locale.US);if(!p.getString("pass_"+user,"").equals(pw.getText().toString())){toast("Username or password is incorrect.");return;}me=user;p.edit().putString("logged_user",user).apply();home();}));root.addView(btn("Create a new account",v->signup()));}
    void home(){setup();title("Vibely","Find people and stay connected.");root.addView(btn("🔎  Search people",v->search()));root.addView(btn("✨  Discover",v->discover()));root.addView(btn("👤  My Profile",v->profile(me)));root.addView(btn("🤝  Connections",v->connections()));root.addView(btn("💬  Messages",v->messages()));gap(8);root.addView(btn("Edit profile",v->editProfile()));root.addView(btn("My interests",v->interestPage()));root.addView(btn("Log out",v->{p.edit().remove("logged_user").apply();me="";welcome();}));}
    void search(){setup();title("Search","Find people by name or username.");EditText q=input("Type a name or username...");root.addView(q);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(scroll(results),new LinearLayout.LayoutParams(-1,0,1));root.addView(btn("Search",v->{results.removeAllViews();String x=q.getText().toString().trim().toLowerCase(Locale.US);if(x.isEmpty()){results.addView(tv("Type something to search.",15,false));return;}boolean found=false;for(int i=0;i<names.length;i++)if(names[i].toLowerCase(Locale.US).contains(x)||users[i].contains(x)){person(results,names[i],users[i]);found=true;}String mn=p.getString("name_"+me,"");if(mn.toLowerCase(Locale.US).contains(x)||me.contains(x)){person(results,mn,me);found=true;}if(!found)results.addView(tv("No people found.",15,false));}));root.addView(btn("← Back",v->home()));}
    void person(LinearLayout par,String name,String user){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(d(12),d(8),d(12),d(8));c.setBackgroundColor(Color.rgb(25,25,34));c.addView(tv(name,18,true));TextView u=tv("@"+user,13,false);u.setTextColor(Color.LTGRAY);c.addView(u);c.addView(btn("View profile",v->profile(user)));par.addView(c);}
    void discover(){setup();title("Discover","People you may want to connect with.");LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<names.length;i++)person(c,names[i],users[i]);root.addView(scroll(c),new LinearLayout.LayoutParams(-1,0,1));root.addView(btn("← Back",v->home()));}
    String display(String user){String n=p.getString("name_"+user,"");if(!n.isEmpty())return n;for(int i=0;i<users.length;i++)if(users[i].equals(user))return names[i];return user;}
    void profile(String incomingUser){
        setup();
        final String profileUser=incomingUser.replace("@","").trim().toLowerCase(Locale.US);
        title(display(profileUser),"@"+profileUser);
        TextView b=tv(p.getString("bio_"+profileUser,"Hello! I'm on Vibely."),15,false);
        b.setTextColor(Color.LTGRAY);
        root.addView(b);
        if(profileUser.equals(me)){
            root.addView(btn("Edit profile",v->editProfile()));
        }else{
            root.addView(btn("Connect",v->{
                p.edit().putBoolean("connected_"+profileUser,true).apply();
                toast("Connection request sent.");
            }));
            root.addView(btn("Report / Block",v->safety(profileUser)));
        }
        root.addView(btn("← Back",v->home()));
    }
    void safety(String user){String[] a={"Report user","Block user","Cancel"};new AlertDialog.Builder(this).setTitle("Safety options").setItems(a,(x,w)->{if(w==0)toast("Report submitted in demo mode.");if(w==1){p.edit().putBoolean("blocked_"+user,true).apply();toast("User blocked.");}}).show();}
    void editProfile(){setup();title("Edit profile","Changes are saved on this device.");EditText n=input("Display name"),b=input("Bio");n.setText(p.getString("name_"+me,me));b.setText(p.getString("bio_"+me,""));root.addView(n);root.addView(b);root.addView(btn("Save changes",v->{if(n.getText().toString().trim().length()<2){toast("Name is too short.");return;}p.edit().putString("name_"+me,n.getText().toString().trim()).putString("bio_"+me,b.getText().toString().trim()).apply();toast("Profile updated.");profile(me);}));root.addView(btn("← Back",v->home()));}
    void interestPage(){setup();title("Your Interests","Choose up to 8.");String[] a={"Music","Gaming","Football","Movies","Art","Tech","Books","Travel","Photography","Fashion","Fitness","Coding"};Set<String> selected=new HashSet<>();String old=p.getString("interests_"+me,"");if(!old.isEmpty())selected.addAll(Arrays.asList(old.split("\\|")));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);for(String s:a){CheckBox cb=new CheckBox(this);cb.setText(s);cb.setTextColor(Color.WHITE);cb.setTextSize(16);cb.setChecked(selected.contains(s));cb.setOnCheckedChangeListener((v,checked)->{if(checked){if(selected.size()>=8){v.setChecked(false);toast("Maximum 8 interests.");}else selected.add(s);}else selected.remove(s);});list.addView(cb);}root.addView(scroll(list),new LinearLayout.LayoutParams(-1,0,1));root.addView(btn("Save interests",v->{StringBuilder z=new StringBuilder();for(String s:selected){if(z.length()>0)z.append("|");z.append(s);}p.edit().putString("interests_"+me,z.toString()).apply();toast("Interests saved.");home();}));root.addView(btn("← Back",v->home()));}
    void connections(){setup();title("Connections","People you've connected with.");boolean any=false;for(int i=0;i<users.length;i++)if(p.getBoolean("connected_"+users[i],false)){person(root,names[i],users[i]);any=true;}if(!any)root.addView(tv("No connections yet. Try Discover.",15,false));root.addView(btn("← Back",v->home()));}
    void messages(){setup();title("Messages","Messaging area");root.addView(tv("This build is offline. Online messaging can be connected to Supabase in a future version.",15,false));root.addView(btn("← Back",v->home()));}
}
