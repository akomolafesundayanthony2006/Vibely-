# Vibely Final
Java Android demo with welcome, signup/login, search, discover, profiles, edit profile, interests, connections, messages placeholder, connect and report/block.
