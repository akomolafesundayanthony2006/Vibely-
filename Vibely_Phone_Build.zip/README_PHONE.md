# Vibely phone-only build

Upload all files in this ZIP to your GitHub repository, keeping folders intact.

Then:
1. Open Actions.
2. Choose Build Vibely APK.
3. Tap Run workflow.
4. Wait for it to finish.
5. Open the completed run.
6. Download the Vibely-apk artifact.
7. Extract it and install app-debug.apk.

This build is the native app foundation. Supabase production authentication is not wired into this native build yet. Never add a Supabase secret/service_role key to the app.
