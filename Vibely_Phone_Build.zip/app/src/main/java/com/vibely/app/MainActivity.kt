package com.vibely.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val interests = listOf("Gaming","Music","Sports","Movies","Books","Art","Technology","Comedy","Travel","Photography","Cooking","Fashion","Fitness","Anime","Football","Basketball","Coding","Nature","Dance","Writing")
    override fun onCreate(state: Bundle?) { super.onCreate(state); welcome() }
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,36,28,20);setBackgroundColor(Color.WHITE)}
    private fun title(s:String)=TextView(this).apply{text=s;textSize=30f;setTextColor(Color.DKGRAY);setPadding(0,0,0,18)}
    private fun btn(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
    private fun welcome(){val r=root();r.gravity=Gravity.CENTER;r.addView(title("Vibely").apply{textSize=42f});r.addView(TextView(this).apply{text="Meet people. Share interests. Find your vibe.";textSize=18f;gravity=Gravity.CENTER;setPadding(0,0,0,24)});r.addView(btn("Create account"){signup()});r.addView(btn("Log in"){login()});setContentView(r)}
    private fun signup(){val r=root();r.addView(title("Create account"));r.addView(EditText(this).apply{hint="Email"});r.addView(EditText(this).apply{hint="Password";inputType=129});r.addView(btn("Continue"){interests()});r.addView(btn("Back"){welcome()});setContentView(r)}
    private fun login(){val r=root();r.addView(title("Log in"));r.addView(EditText(this).apply{hint="Email"});r.addView(EditText(this).apply{hint="Password";inputType=129});r.addView(btn("Log in"){home()});r.addView(btn("Back"){welcome()});setContentView(r)}
    private fun interests(){val r=root();r.addView(title("Your interests"));r.addView(TextView(this).apply{text="Choose up to 8";textSize=16f});val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val cs=interests.map{CheckBox(this).apply{text=it;textSize=16f}};cs.forEach{c->c.setOnCheckedChangeListener{_,on->if(on&&cs.count{it.isChecked}>8){c.isChecked=false;Toast.makeText(this,"Maximum 8 interests",Toast.LENGTH_SHORT).show()}};box.addView(c)};r.addView(ScrollView(this).apply{addView(box)},LinearLayout.LayoutParams(-1,0,1f));r.addView(btn("Finish"){home()});setContentView(r)}
    private fun home(){val r=root();r.addView(title("Vibely"));r.addView(TextView(this).apply{text="Find people who share your vibe.";textSize=18f});r.addView(btn("Discover"){page("Discover","People with shared interests will appear here.")});r.addView(btn("My interests"){interests()});r.addView(btn("Connections"){page("Connections","Your connections will appear here.")});r.addView(btn("Messages"){page("Messages","Your conversations will appear here.")});r.addView(btn("Profile"){page("Profile","Your profile will appear here.")});setContentView(r)}
    private fun page(t:String,m:String){val r=root();r.addView(title(t));r.addView(TextView(this).apply{text=m;textSize=18f});r.addView(btn("Back"){home()});setContentView(r)}
}
