# Vibely v2 — Search + Profile Update

This version improves the Android foundation with:
- Search people by name/username from Home.
- Discover screen with profile cards.
- View-profile screen with Connect and Report/Block safety options.
- Working My Profile screen with display name, username and bio.
- Profile changes are saved locally on the phone so they remain visible after leaving the screen.
- Cleaner dark Vibely UI.
- Version 1.1 / versionCode 2.

## Build from phone with GitHub Actions
1. Upload this project to the Vibely GitHub repository.
2. Run the Build Vibely APK workflow.
3. Download the `Vibely-apk` artifact.
4. Install the generated APK on the phone.

This is the next Android UI build. The search data is currently demo/local data; the next backend step can connect search and profiles to Supabase.
