package com.vibely.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val interests = listOf("Gaming","Music","Sports","Movies","Books","Art","Technology","Comedy","Travel","Photography","Cooking","Fashion","Fitness","Anime","Football","Basketball","Coding","Nature","Dance","Writing")
    private val people = listOf(
        Person("Alex", "@alex", "Gaming • Music", "I love games, music and meeting people with the same vibe."),
        Person("Maya", "@maya", "Art • Movies", "Creative soul who loves movies and drawing."),
        Person("Jordan", "@jordan", "Football • Sports", "Sports fan and football lover."),
        Person("Chris", "@chris", "Coding • Technology", "Building things and learning new tech."),
        Person("Tobi", "@tobi", "Anime • Gaming", "Anime, games and good conversations."),
        Person("Sam", "@sam", "Books • Writing", "Always reading or writing something new.")
    )

    data class Person(val name: String, val username: String, val interests: String, val bio: String)

    private val prefs by lazy { getSharedPreferences("vibely_profile", Context.MODE_PRIVATE) }
    private var selected = mutableSetOf<String>()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        welcome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(24), dp(20), dp(24))
        setBackgroundColor(Color.rgb(9, 7, 25))
    }

    private fun title(text: String, size: Float = 30f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(10))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun muted(text: String): TextView = TextView(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.rgb(185, 180, 205)); setPadding(0, 0, 0, dp(12))
    }

    private fun button(text: String, action: () -> Unit, secondary: Boolean = false): Button = Button(this).apply {
        this.text = text; textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
        background = bg(if (secondary) Color.rgb(33, 27, 59) else Color.rgb(112, 44, 255), 16)
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, dp(52)); p.setMargins(0, dp(8), 0, 0); layoutParams = p
    }

    private fun addSpace(parent: ViewGroup, h: Int) { parent.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun welcome() {
        val r = root(); r.gravity = Gravity.CENTER_HORIZONTAL
        addSpace(r, 70)
        r.addView(title("♥  Vibely", 42f))
        r.addView(muted("Find your people. Find your vibe."))
        addSpace(r, 20)
        r.addView(button("Create account") { signup() })
        r.addView(button("Log in") { login() }, LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(r)
    }

    private fun signup() {
        val r = root(); r.addView(title("Create your account")); r.addView(muted("Start your Vibely profile."))
        val name = EditText(this).apply { hint = "Display name"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        val email = EditText(this).apply { hint = "Email"; inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        r.addView(name, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0,dp(8),0,0) })
        r.addView(email, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0,dp(8),0,0) })
        r.addView(button("Continue") { prefs.edit().putString("name", name.text.toString().trim().ifEmpty { "Vibely user" }).apply(); interests() })
        r.addView(button("Back") { welcome() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        setContentView(r)
    }

    private fun login() {
        val r = root(); r.addView(title("Log in")); r.addView(muted("Welcome back to Vibely."))
        val email = EditText(this).apply { hint = "Email"; inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        val password = EditText(this).apply { hint = "Password"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        r.addView(email, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0,dp(8),0,0) })
        r.addView(password, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0,dp(8),0,0) })
        r.addView(button("Log in") { home() })
        r.addView(button("Back") { welcome() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        setContentView(r)
    }

    private fun home() {
        val r = root(); r.addView(title("Vibely", 34f))
        r.addView(muted("Welcome, ${prefs.getString("name", "Vibely user")} 👋"))
        val search = EditText(this).apply {
            hint = "🔎  Search people by name..."; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(160,155,180)); singleLine = true
            background = bg(Color.rgb(20,17,40)); setPadding(dp(16),0,dp(16),0)
            setOnEditorActionListener { _, _, _ -> searchPeople(text.toString()); true }
        }
        r.addView(search, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(10) })
        r.addView(button("Search") { searchPeople(search.text.toString()) })
        r.addView(button("Discover people") { discover() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        r.addView(button("My profile") { profile() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        r.addView(button("My interests") { interests() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        r.addView(button("Connections & messages") { page("Connections", "Your connections and conversations will appear here.") }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        setContentView(r)
    }

    private fun searchPeople(query: String) {
        val q = query.trim()
        if (q.isEmpty()) { discover(); return }
        val matches = people.filter { it.name.contains(q, true) || it.username.contains(q, true) }
        val r = root(); r.addView(title("Search results")); r.addView(muted(if (matches.isEmpty()) "No profiles found for “$q”." else "People matching “$q”"))
        if (matches.isEmpty()) r.addView(button("Back to home") { home() })
        else {
            val scroll = ScrollView(this); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            matches.forEach { addPersonCard(box, it) }; scroll.addView(box); r.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            r.addView(button("Back") { home() })
        }
        setContentView(r)
    }

    private fun discover() {
        val r = root(); r.addView(title("Discover 🔎")); r.addView(muted("Search for people you know or browse these profiles."))
        val scroll = ScrollView(this); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        people.forEach { addPersonCard(box, it) }; scroll.addView(box); r.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        r.addView(button("Back to home") { home() }); setContentView(r)
    }

    private fun addPersonCard(parent: LinearLayout, p: Person) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); background = bg(Color.rgb(21,17,45), 18) }
        card.addView(TextView(this).apply { text = "${p.name}  ${p.username}"; textSize = 19f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        card.addView(TextView(this).apply { text = p.interests; textSize = 14f; setTextColor(Color.rgb(215,190,255)); setPadding(0,dp(5),0,0) })
        card.addView(TextView(this).apply { text = p.bio; textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0,dp(5),0,dp(5) ) })
        card.addView(button("View profile") { viewPerson(p) })
        parent.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,dp(12)) })
    }

    private fun viewPerson(p: Person) {
        val r = root(); r.addView(title(p.name)); r.addView(muted(p.username));
        r.addView(TextView(this).apply { text = p.bio; textSize = 17f; setTextColor(Color.WHITE); setPadding(0,0,0,dp(14)) })
        r.addView(TextView(this).apply { text = "Interests\n${p.interests}"; textSize = 16f; setTextColor(Color.rgb(210,205,225)); setPadding(0,0,0,dp(18)) })
        r.addView(button("Connect") { Toast.makeText(this, "Connection request sent", Toast.LENGTH_SHORT).show() })
        r.addView(button("Report / block", { Toast.makeText(this, "Safety options opened", Toast.LENGTH_SHORT).show() }, true))
        r.addView(button("Back") { discover() }, LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(8)})
        setContentView(r)
    }

    private fun profile() {
        val r = root(); r.addView(title("My Profile 👤")); r.addView(muted("This is how your profile appears to you."))
        val name = EditText(this).apply { hint = "Display name"; setText(prefs.getString("name", "Vibely user")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        val username = EditText(this).apply { hint = "Username"; setText(prefs.getString("username", "@vibelyuser")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = bg(Color.rgb(20,17,40)); setPadding(dp(14),0,dp(14),0) }
        val bio = EditText(this).apply { hint = "Bio"; setText(prefs.getString("bio", "Tell people a little about you.")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); gravity = Gravity.TOP; background = bg(Color.rgb(20,17,40)); setPadding(dp(14),dp(14),dp(14),dp(14)) }
        r.addView(name, LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(6),0,0)})
        r.addView(username, LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,0)})
        r.addView(bio, LinearLayout.LayoutParams(-1,dp(110)).apply{setMargins(0,dp(8),0,0)})
        r.addView(button("Save profile") { prefs.edit().putString("name", name.text.toString().trim().ifEmpty { "Vibely user" }).putString("username", username.text.toString().trim()).putString("bio", bio.text.toString().trim()).apply(); Toast.makeText(this,"Profile saved ✓",Toast.LENGTH_SHORT).show(); home() })
        r.addView(button("Back") { home() }, LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(8)})
        setContentView(r)
    }

    private fun interests() {
        val r = root(); r.addView(title("Your interests 🎯")); r.addView(muted("Choose up to 8 interests."))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = interests.map { value -> CheckBox(this).apply { text = value; textSize = 16f; setTextColor(Color.WHITE); isChecked = selected.contains(value) } }
        checks.forEach { c -> c.setOnCheckedChangeListener { _, on -> if(on && checks.count{it.isChecked}>8){c.isChecked=false;Toast.makeText(this,"Maximum 8 interests",Toast.LENGTH_SHORT).show()} }; box.addView(c) }
        r.addView(ScrollView(this).apply{addView(box)}, LinearLayout.LayoutParams(-1,0,1f))
        r.addView(button("Save interests") { selected = checks.filter{it.isChecked}.map{it.text.toString()}.toMutableSet(); Toast.makeText(this,"Interests saved ✓",Toast.LENGTH_SHORT).show(); home() })
        r.addView(button("Back") { home() }, LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(8)})
        setContentView(r)
    }

    private fun page(t: String, m: String) { val r=root(); r.addView(title(t)); r.addView(muted(m)); r.addView(button("Back") { home() }); setContentView(r) }
}
