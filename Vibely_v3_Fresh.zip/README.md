Vibely v5 Feed

Android demo app with local login, profiles, search, discover, connections, messages, interests, a local feed, create-post, likes and comments.

Build with Java 17 / Android Gradle Plugin.
