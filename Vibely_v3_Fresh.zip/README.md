# Vibely 1.5

Polished Java Android prototype with rounded controls, a cleaner home screen, fixed bottom navigation, search, discover, profiles, interests, connections and local demo login.

This build remains local/offline. Online accounts and messaging require a backend such as Supabase.
