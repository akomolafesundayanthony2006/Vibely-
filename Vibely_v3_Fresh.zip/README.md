# Vibely v3
Fresh project with the Android project at ZIP root.
Includes login/signup, home, search, discover, profile editing, interests, connections, messages, connect and report/block.
Profile data is stored locally in this demo. Supabase will be connected in the backend step.
