# Vibely 1.3

Fresh Android project for Vibely. This version uses Java for the main activity to avoid the Kotlin syntax/compiler issue from the previous build.

Features:
- Welcome screen
- Local demo sign up / log in
- Home
- Search people by name or username
- Discover
- Profiles
- Connect
- Report / Block placeholder
- Edit profile
- Up to 8 interests
- Connections
- Messages
- Local persistence with SharedPreferences

This is still a local demo; it is not connected to Supabase yet.
