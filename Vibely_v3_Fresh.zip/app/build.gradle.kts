plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.vibely.app"
    compileSdk=35
    defaultConfig {
        applicationId="com.vibely.app"
        minSdk=23
        targetSdk=35
        versionCode=3
        versionName="1.2"
    }
    compileOptions {
        sourceCompatibility=JavaVersion.VERSION_17
        targetCompatibility=JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget="17" }
}