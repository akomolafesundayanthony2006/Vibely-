plugins {
    id("com.android.application")
}

android {
    namespace = "com.vibely.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vibely.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
