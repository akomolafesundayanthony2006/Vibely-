package com.vibely.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private String currentUser = "";
    private final ArrayList<String> selectedInterests = new ArrayList<>();

    private final String[] demoNames = {
            "Alex Johnson", "Maya Ade", "Daniel Cole", "Sarah James",
            "Chris Bello", "Tobi Kay", "Peace Obi", "Jordan Lee"
    };
    private final String[] demoUsers = {
            "alex", "maya", "daniel", "sarah", "chris", "tobi", "peace", "jordan"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vibely_data", MODE_PRIVATE);
        currentUser = prefs.getString("logged_user", "");
        if (currentUser.isEmpty()) showWelcome();
        else {
            loadInterests();
            showHome();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(10, 10, 16));
        setContentView(root);
    }

    private TextView label(String value, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(150, 150, 160));
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackgroundColor(Color.rgb(28, 28, 38));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        return e;
    }

    private Button action(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setOnClickListener(listener);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(91, 55, 170));
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(5), 0, dp(5));
        b.setLayoutParams(p);
        return b;
    }

    private TextView navItem(String icon, String name, View.OnClickListener listener) {
        TextView item = new TextView(this);
        item.setText(icon + "\n" + name);
        item.setTextColor(Color.rgb(210, 205, 225));
        item.setTextSize(11);
        item.setGravity(Gravity.CENTER);
        item.setPadding(0, dp(7), 0, dp(5));
        item.setOnClickListener(listener);
        return item;
    }

    private LinearLayout bottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(6), dp(5), dp(6), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(24, 22, 32));
        bg.setCornerRadius(dp(18));
        nav.setBackground(bg);
        nav.addView(navItem("⌂", "Home", v -> showHome()), new LinearLayout.LayoutParams(0, dp(58), 1));
        nav.addView(navItem("⌕", "Search", v -> showSearch()), new LinearLayout.LayoutParams(0, dp(58), 1));
        nav.addView(navItem("✦", "Discover", v -> showDiscover()), new LinearLayout.LayoutParams(0, dp(58), 1));
        nav.addView(navItem("●", "Profile", v -> showProfile(currentUser)), new LinearLayout.LayoutParams(0, dp(58), 1));
        return nav;
    }

    private void header(String title, String subtitle) {
        root.addView(label(title, 27, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = label(subtitle, 14, false);
            s.setTextColor(Color.rgb(180, 180, 192));
            root.addView(s);
        }
    }

    private void gap(int height) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        root.addView(s);
    }

    private ScrollView scroll(LinearLayout content) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.addView(content);
        return s;
    }

    private LinearLayout verticalContent() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showWelcome() {
        setupRoot();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        gap(55);
        TextView logo = label("Vibely", 42, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo);
        TextView sub = label("Meet people. Share moments. Be yourself.", 16, false);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.rgb(190, 190, 205));
        root.addView(sub);
        gap(22);
        root.addView(action("Create account", v -> showSignup()));
        root.addView(action("Log in", v -> showLogin()));
        TextView note = label("Local demo • data stays on this device", 12, false);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.GRAY);
        root.addView(note);
    }

    private void showSignup() {
        setupRoot();
        header("Create your account", "Choose a name, username and password.");
        EditText name = field("Display name");
        EditText username = field("Username");
        EditText password = field("Password");
        EditText confirm = field("Confirm password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(name); root.addView(username); root.addView(password); root.addView(confirm);

        root.addView(action("Create account", v -> {
            String n = name.getText().toString().trim();
            String u = normalize(username.getText().toString());
            String p = password.getText().toString();
            String c = confirm.getText().toString();
            if (n.length() < 2 || u.length() < 2 || p.length() < 4) {
                toast("Enter a valid name, username and 4+ character password.");
                return;
            }
            if (!p.equals(c)) {
                toast("Passwords do not match.");
                return;
            }
            if (prefs.contains("pass_" + u)) {
                toast("That username is already in use.");
                return;
            }
            prefs.edit()
                    .putString("name_" + u, n)
                    .putString("pass_" + u, p)
                    .putString("bio_" + u, "New to Vibely 👋")
                    .putString("logged_user", u)
                    .apply();
            currentUser = u;
            selectedInterests.clear();
            showHome();
        }));
        root.addView(action("Already have an account? Log in", v -> showLogin()));
    }

    private void showLogin() {
        setupRoot();
        header("Welcome back", "Log in to continue.");
        EditText username = field("Username");
        EditText password = field("Password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(username); root.addView(password);
        root.addView(action("Log in", v -> {
            String u = normalize(username.getText().toString());
            String saved = prefs.getString("pass_" + u, "");
            if (u.isEmpty() || !saved.equals(password.getText().toString())) {
                toast("Username or password is incorrect.");
                return;
            }
            currentUser = u;
            prefs.edit().putString("logged_user", u).apply();
            loadInterests();
            showHome();
        }));
        root.addView(action("Create a new account", v -> showSignup()));
    }

    private void showHome() {
        setupRoot();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(label("Vibely", 30, true));
        TextView sub = label("Your feed", 13, false);
        sub.setTextColor(Color.rgb(175, 175, 190));
        brand.addView(sub);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        TextView note = label("✦", 25, true);
        note.setTextColor(Color.rgb(165, 120, 255));
        note.setGravity(Gravity.CENTER);
        top.addView(note, new LinearLayout.LayoutParams(dp(42), dp(42)));
        root.addView(top);

        LinearLayout feed = verticalContent();
        addCreatePostCard(feed);
        addSavedPosts(feed);
        addDemoPost(feed, "Alex Johnson", "alex", "Building something new today. Small steps, big ideas 🚀", "demo_alex");
        addDemoPost(feed, "Maya Ade", "maya", "Just joined Vibely ✨ Who else is here?", "demo_maya");
        addDemoPost(feed, "Peace Obi", "peace", "Good vibes only. Have a great day 💜", "demo_peace");

        root.addView(scroll(feed), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(bottomNav());
        root.addView(action("Log out", v -> {
            prefs.edit().remove("logged_user").apply();
            currentUser = "";
            showWelcome();
        }));
    }



    private void addCreatePostCard(LinearLayout parent) {
        LinearLayout card = postCardContainer();
        TextView title = label("Create a post", 17, true);
        card.addView(title);
        TextView hint = label("What's on your mind?", 14, false);
        hint.setTextColor(Color.rgb(165, 165, 180));
        card.addView(hint);
        card.addView(action("＋  Post something", v -> createPost()));
        parent.addView(card);
        gapIn(parent, 10);
    }

    private LinearLayout postCardContainer() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(24, 24, 33));
        bg.setCornerRadius(dp(16));
        card.setBackground(bg);
        return card;
    }

    private void gapIn(LinearLayout parent, int height) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        parent.addView(s);
    }

    private void addSavedPosts(LinearLayout parent) {
        Map<String, ?> all = prefs.getAll();
        ArrayList<String> ids = new ArrayList<>();
        for (String key : all.keySet()) {
            if (key.startsWith("post_body_")) {
                ids.add(key.substring("post_body_".length()));
            }
        }
        Collections.sort(ids, Collections.reverseOrder());
        for (String id : ids) {
            String user = prefs.getString("post_user_" + id, currentUser);
            String body = prefs.getString("post_body_" + id, "");
            addPostCard(parent, displayName(user), user, body, id);
        }
    }

    private void addDemoPost(LinearLayout parent, String name, String username, String body, String id) {
        addPostCard(parent, name, username, body, id);
    }

    private void addPostCard(LinearLayout parent, String name, String username, String body, String id) {
        LinearLayout card = postCardContainer();

        LinearLayout author = new LinearLayout(this);
        author.setOrientation(LinearLayout.HORIZONTAL);
        author.setGravity(Gravity.CENTER_VERTICAL);

        TextView avatar = label("●", 25, true);
        avatar.setTextColor(Color.rgb(145, 95, 240));
        author.addView(avatar, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(label(name, 16, true));
        TextView handle = label("@" + username, 12, false);
        handle.setTextColor(Color.rgb(165, 165, 180));
        names.addView(handle);
        author.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        author.setOnClickListener(v -> showProfile(username));
        card.addView(author);

        TextView text = label(body, 16, false);
        text.setPadding(0, dp(10), 0, dp(10));
        card.addView(text);

        int likes = prefs.getInt("likes_" + id, id.startsWith("demo_") ? demoLikes(id) : 0);
        int comments = prefs.getInt("comments_" + id, 0);
        TextView counts = label(likes + " likes   •   " + comments + " comments", 12, false);
        counts.setTextColor(Color.rgb(145, 145, 160));
        card.addView(counts);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        final Button like = action("♡ Like", v -> {
            boolean liked = prefs.getBoolean("liked_" + id + "_" + currentUser, false);
            int value = prefs.getInt("likes_" + id, id.startsWith("demo_") ? demoLikes(id) : 0);
            if (liked) {
                liked = false;
                value = Math.max(0, value - 1);
            } else {
                liked = true;
                value++;
            }
            prefs.edit().putBoolean("liked_" + id + "_" + currentUser, liked)
                    .putInt("likes_" + id, value).apply();
            like.setText(liked ? "♥ Liked" : "♡ Like");
            counts.setText(value + " likes   •   " + prefs.getInt("comments_" + id, comments) + " comments");
        });
        if (prefs.getBoolean("liked_" + id + "_" + currentUser, false)) like.setText("♥ Liked");

        Button comment = action("💬 Comment", v -> showComments(id, name));
        actions.addView(like, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(comment, new LinearLayout.LayoutParams(0, dp(48), 1));
        card.addView(actions);

        parent.addView(card);
        gapIn(parent, 10);
    }

    private int demoLikes(String id) {
        if ("demo_alex".equals(id)) return 7;
        if ("demo_maya".equals(id)) return 12;
        return 5;
    }

    private void createPost() {
        final EditText input = field("Write something...");
        input.setSingleLine(false);
        input.setMinLines(4);
        input.setGravity(Gravity.TOP);
        new AlertDialog.Builder(this)
                .setTitle("Create a post")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Post", (dialog, which) -> {
                    String body = input.getText().toString().trim();
                    if (body.length() < 1) {
                        toast("Write something first.");
                        return;
                    }
                    String id = String.valueOf(System.currentTimeMillis());
                    prefs.edit()
                            .putString("post_body_" + id, body)
                            .putString("post_user_" + id, currentUser)
                            .putInt("likes_" + id, 0)
                            .putInt("comments_" + id, 0)
                            .apply();
                    toast("Posted to your feed.");
                    showHome();
                }).show();
    }

    private void showComments(final String postId, String authorName) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(4), dp(4), dp(4));

        int count = prefs.getInt("comments_" + postId, 0);
        if (count == 0) {
            TextView empty = label("No comments yet. Be the first!", 14, false);
            empty.setTextColor(Color.LTGRAY);
            box.addView(empty);
        } else {
            for (int i = 0; i < count; i++) {
                String comment = prefs.getString("comment_" + postId + "_" + i, "");
                if (!comment.isEmpty()) box.addView(label(comment, 14, false));
            }
        }

        final EditText input = field("Write a comment...");
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Comments on " + authorName + "'s post")
                .setView(box)
                .setNegativeButton("Close", null)
                .setPositiveButton("Send", (dialog, which) -> {
                    String text = input.getText().toString().trim();
                    if (text.isEmpty()) {
                        toast("Write a comment first.");
                        return;
                    }
                    int next = prefs.getInt("comments_" + postId, 0);
                    prefs.edit()
                            .putString("comment_" + postId + "_" + next,
                                    displayName(currentUser) + ": " + text)
                            .putInt("comments_" + postId, next + 1)
                            .apply();
                    toast("Comment added.");
                    showHome();
                }).show();
    }

    private void showSearch() {
        setupRoot();
        header("Search people", "Search by display name or username.");
        EditText query = field("Type a name or username...");
        root.addView(query);
        LinearLayout results = verticalContent();
        root.addView(scroll(results), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("Search", v -> {
            results.removeAllViews();
            String q = query.getText().toString().trim().toLowerCase(Locale.US);
            if (q.isEmpty()) {
                results.addView(label("Type something to search.", 15, false));
                return;
            }
            boolean found = false;
            for (int i = 0; i < demoUsers.length; i++) {
                if (demoNames[i].toLowerCase(Locale.US).contains(q) || demoUsers[i].contains(q)) {
                    addPerson(results, demoNames[i], demoUsers[i]);
                    found = true;
                }
            }
            String myName = prefs.getString("name_" + currentUser, "");
            if (myName.toLowerCase(Locale.US).contains(q) || currentUser.contains(q)) {
                addPerson(results, myName, currentUser);
                found = true;
            }
            if (!found) results.addView(label("No people found.", 15, false));
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void addPerson(LinearLayout parent, String name, String username) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.rgb(24, 24, 33));
        cardBg.setCornerRadius(dp(16));
        card.setBackground(cardBg);
        card.addView(label(name, 18, true));
        TextView u = label("@" + username, 13, false);
        u.setTextColor(Color.LTGRAY);
        card.addView(u);
        card.addView(action("View profile", v -> showProfile(username)));
        parent.addView(card);
        Space gap = new Space(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(1, dp(8)));
        parent.addView(gap);
    }

    private void showDiscover() {
        setupRoot();
        header("Discover", "People you may want to connect with.");
        LinearLayout list = verticalContent();
        for (int i = 0; i < demoUsers.length; i++) addPerson(list, demoNames[i], demoUsers[i]);
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("← Back", v -> showHome()));
    }

    private String normalize(String value) {
        return value.trim().replace(" ", "").replace("@", "").toLowerCase(Locale.US);
    }

    private String displayName(String username) {
        String stored = prefs.getString("name_" + username, "");
        if (!stored.isEmpty()) return stored;
        for (int i = 0; i < demoUsers.length; i++) {
            if (demoUsers[i].equalsIgnoreCase(username)) return demoNames[i];
        }
        return username;
    }

    private void showProfile(String incomingUsername) {
        setupRoot();
        final String profileUser = normalize(incomingUsername);
        header(displayName(profileUser), "@" + profileUser);
        TextView bio = label(prefs.getString("bio_" + profileUser, "Hello! I'm on Vibely."), 15, false);
        bio.setTextColor(Color.rgb(195, 195, 205));
        root.addView(bio);
        gap(6);

        if (profileUser.equalsIgnoreCase(currentUser)) {
            root.addView(action("Edit profile", v -> showEditProfile()));
            root.addView(action("Edit interests", v -> showInterests()));
        } else {
            root.addView(action("Connect", v -> {
                prefs.edit().putBoolean("connected_" + profileUser, true).apply();
                toast("Connection request sent.");
            }));
            root.addView(action("Report / Block", v -> showSafety(profileUser)));
        }
        root.addView(action("← Back", v -> showHome()));
    }

    private void showSafety(final String username) {
        String[] choices = {"Report user", "Block user", "Cancel"};
        new AlertDialog.Builder(this)
                .setTitle("Safety options")
                .setItems(choices, (dialog, which) -> {
                    if (which == 0) toast("Report submitted in demo mode.");
                    else if (which == 1) {
                        prefs.edit().putBoolean("blocked_" + username, true).apply();
                        toast("User blocked in demo mode.");
                    }
                })
                .show();
    }

    private void showEditProfile() {
        setupRoot();
        header("Edit profile", "Your changes are saved on this device.");
        EditText name = field("Display name");
        EditText bio = field("Bio");
        name.setText(prefs.getString("name_" + currentUser, currentUser));
        bio.setText(prefs.getString("bio_" + currentUser, ""));
        root.addView(name); root.addView(bio);
        root.addView(action("Save changes", v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 2) {
                toast("Display name is too short.");
                return;
            }
            prefs.edit().putString("name_" + currentUser, n)
                    .putString("bio_" + currentUser, bio.getText().toString().trim()).apply();
            toast("Profile updated.");
            showProfile(currentUser);
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void showInterests() {
        setupRoot();
        header("Your interests", "Choose up to 8 interests.");
        final Set<String> selected = new HashSet<>(selectedInterests);
        String[] choices = {"Music", "Gaming", "Football", "Movies", "Art", "Tech", "Books", "Travel",
                "Photography", "Fashion", "Fitness", "Coding"};
        LinearLayout list = verticalContent();
        for (String choice : choices) {
            CheckBox box = new CheckBox(this);
            box.setText(choice);
            box.setTextColor(Color.WHITE);
            box.setTextSize(16);
            box.setChecked(selected.contains(choice));
            final String interest = choice;
            box.setOnCheckedChangeListener((buttonView, checked) -> {
                if (checked) {
                    if (selected.size() >= 8) {
                        buttonView.setChecked(false);
                        toast("You can choose up to 8 interests.");
                    } else selected.add(interest);
                } else selected.remove(interest);
            });
            list.addView(box);
        }
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("Save interests", v -> {
            selectedInterests.clear();
            selectedInterests.addAll(selected);
            saveInterests();
            toast("Interests saved.");
            showHome();
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void loadInterests() {
        selectedInterests.clear();
        String raw = prefs.getString("interests_" + currentUser, "");
        if (!raw.isEmpty()) selectedInterests.addAll(Arrays.asList(raw.split("\\|")));
    }

    private void saveInterests() {
        StringBuilder raw = new StringBuilder();
        for (String item : selectedInterests) {
            if (raw.length() > 0) raw.append('|');
            raw.append(item);
        }
        prefs.edit().putString("interests_" + currentUser, raw.toString()).apply();
    }

    private void showConnections() {
        setupRoot();
        header("Connections", "People you've connected with.");
        LinearLayout list = verticalContent();
        boolean found = false;
        for (int i = 0; i < demoUsers.length; i++) {
            if (prefs.getBoolean("connected_" + demoUsers[i], false)) {
                addPerson(list, demoNames[i], demoUsers[i]);
                found = true;
            }
        }
        if (!found) list.addView(label("No connections yet. Try Discover.", 15, false));
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("← Back", v -> showHome()));
    }

    private void showMessages() {
        setupRoot();
        header("Messages", "Your conversations");
        TextView info = label("Messaging is prepared in this version as a local demo. Online messages will require a backend such as Supabase.", 15, false);
        info.setTextColor(Color.rgb(195, 195, 205));
        root.addView(info);
        gap(10);
        root.addView(action("← Back", v -> showHome()));
    }
}
