package com.vibely.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private String currentUser = "";
    private final ArrayList<String> selectedInterests = new ArrayList<>();

    private final String[] demoNames = {
            "Alex Johnson", "Maya Ade", "Daniel Cole", "Sarah James",
            "Chris Bello", "Tobi Kay", "Peace Obi", "Jordan Lee"
    };
    private final String[] demoUsers = {
            "alex", "maya", "daniel", "sarah", "chris", "tobi", "peace", "jordan"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vibely_data", MODE_PRIVATE);
        currentUser = prefs.getString("logged_user", "");
        if (currentUser.isEmpty()) showWelcome();
        else {
            loadInterests();
            showHome();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(10, 10, 16));
        setContentView(root);
    }

    private TextView label(String value, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(150, 150, 160));
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackgroundColor(Color.rgb(28, 28, 38));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        return e;
    }

    private Button action(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        b.setBackgroundColor(Color.rgb(91, 55, 170));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(p);
        return b;
    }

    private void header(String title, String subtitle) {
        root.addView(label(title, 27, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = label(subtitle, 14, false);
            s.setTextColor(Color.rgb(180, 180, 192));
            root.addView(s);
        }
    }

    private void gap(int height) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        root.addView(s);
    }

    private ScrollView scroll(LinearLayout content) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.addView(content);
        return s;
    }

    private LinearLayout verticalContent() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showWelcome() {
        setupRoot();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        gap(55);
        TextView logo = label("Vibely", 42, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo);
        TextView sub = label("Meet people. Share moments. Be yourself.", 16, false);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.rgb(190, 190, 205));
        root.addView(sub);
        gap(22);
        root.addView(action("Create account", v -> showSignup()));
        root.addView(action("Log in", v -> showLogin()));
        TextView note = label("Local demo • data stays on this device", 12, false);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.GRAY);
        root.addView(note);
    }

    private void showSignup() {
        setupRoot();
        header("Create your account", "Choose a name, username and password.");
        EditText name = field("Display name");
        EditText username = field("Username");
        EditText password = field("Password");
        EditText confirm = field("Confirm password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(name); root.addView(username); root.addView(password); root.addView(confirm);

        root.addView(action("Create account", v -> {
            String n = name.getText().toString().trim();
            String u = normalize(username.getText().toString());
            String p = password.getText().toString();
            String c = confirm.getText().toString();
            if (n.length() < 2 || u.length() < 2 || p.length() < 4) {
                toast("Enter a valid name, username and 4+ character password.");
                return;
            }
            if (!p.equals(c)) {
                toast("Passwords do not match.");
                return;
            }
            if (prefs.contains("pass_" + u)) {
                toast("That username is already in use.");
                return;
            }
            prefs.edit()
                    .putString("name_" + u, n)
                    .putString("pass_" + u, p)
                    .putString("bio_" + u, "New to Vibely 👋")
                    .putString("logged_user", u)
                    .apply();
            currentUser = u;
            selectedInterests.clear();
            showHome();
        }));
        root.addView(action("Already have an account? Log in", v -> showLogin()));
    }

    private void showLogin() {
        setupRoot();
        header("Welcome back", "Log in to continue.");
        EditText username = field("Username");
        EditText password = field("Password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(username); root.addView(password);
        root.addView(action("Log in", v -> {
            String u = normalize(username.getText().toString());
            String saved = prefs.getString("pass_" + u, "");
            if (u.isEmpty() || !saved.equals(password.getText().toString())) {
                toast("Username or password is incorrect.");
                return;
            }
            currentUser = u;
            prefs.edit().putString("logged_user", u).apply();
            loadInterests();
            showHome();
        }));
        root.addView(action("Create a new account", v -> showSignup()));
    }

    private void showHome() {
        setupRoot();
        header("Vibely", "Find people and stay connected.");
        root.addView(action("🔎  Search people", v -> showSearch()));
        root.addView(action("✨  Discover", v -> showDiscover()));
        root.addView(action("👤  My profile", v -> showProfile(currentUser)));
        root.addView(action("🤝  Connections", v -> showConnections()));
        root.addView(action("💬  Messages", v -> showMessages()));
        gap(8);
        root.addView(action("Edit profile", v -> showEditProfile()));
        root.addView(action("My interests", v -> showInterests()));
        root.addView(action("Log out", v -> {
            prefs.edit().remove("logged_user").apply();
            currentUser = "";
            showWelcome();
        }));
    }

    private void showSearch() {
        setupRoot();
        header("Search people", "Search by display name or username.");
        EditText query = field("Type a name or username...");
        root.addView(query);
        LinearLayout results = verticalContent();
        root.addView(scroll(results), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("Search", v -> {
            results.removeAllViews();
            String q = query.getText().toString().trim().toLowerCase(Locale.US);
            if (q.isEmpty()) {
                results.addView(label("Type something to search.", 15, false));
                return;
            }
            boolean found = false;
            for (int i = 0; i < demoUsers.length; i++) {
                if (demoNames[i].toLowerCase(Locale.US).contains(q) || demoUsers[i].contains(q)) {
                    addPerson(results, demoNames[i], demoUsers[i]);
                    found = true;
                }
            }
            String myName = prefs.getString("name_" + currentUser, "");
            if (myName.toLowerCase(Locale.US).contains(q) || currentUser.contains(q)) {
                addPerson(results, myName, currentUser);
                found = true;
            }
            if (!found) results.addView(label("No people found.", 15, false));
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void addPerson(LinearLayout parent, String name, String username) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(8), dp(12), dp(8));
        card.setBackgroundColor(Color.rgb(25, 25, 34));
        card.addView(label(name, 18, true));
        TextView u = label("@" + username, 13, false);
        u.setTextColor(Color.LTGRAY);
        card.addView(u);
        card.addView(action("View profile", v -> showProfile(username)));
        parent.addView(card);
        Space gap = new Space(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(1, dp(8)));
        parent.addView(gap);
    }

    private void showDiscover() {
        setupRoot();
        header("Discover", "People you may want to connect with.");
        LinearLayout list = verticalContent();
        for (int i = 0; i < demoUsers.length; i++) addPerson(list, demoNames[i], demoUsers[i]);
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("← Back", v -> showHome()));
    }

    private String normalize(String value) {
        return value.trim().replace(" ", "").replace("@", "").toLowerCase(Locale.US);
    }

    private String displayName(String username) {
        String stored = prefs.getString("name_" + username, "");
        if (!stored.isEmpty()) return stored;
        for (int i = 0; i < demoUsers.length; i++) {
            if (demoUsers[i].equalsIgnoreCase(username)) return demoNames[i];
        }
        return username;
    }

    private void showProfile(String incomingUsername) {
        setupRoot();
        final String profileUser = normalize(incomingUsername);
        header(displayName(profileUser), "@" + profileUser);
        TextView bio = label(prefs.getString("bio_" + profileUser, "Hello! I'm on Vibely."), 15, false);
        bio.setTextColor(Color.rgb(195, 195, 205));
        root.addView(bio);
        gap(6);

        if (profileUser.equalsIgnoreCase(currentUser)) {
            root.addView(action("Edit profile", v -> showEditProfile()));
            root.addView(action("Edit interests", v -> showInterests()));
        } else {
            root.addView(action("Connect", v -> {
                prefs.edit().putBoolean("connected_" + profileUser, true).apply();
                toast("Connection request sent.");
            }));
            root.addView(action("Report / Block", v -> showSafety(profileUser)));
        }
        root.addView(action("← Back", v -> showHome()));
    }

    private void showSafety(final String username) {
        String[] choices = {"Report user", "Block user", "Cancel"};
        new AlertDialog.Builder(this)
                .setTitle("Safety options")
                .setItems(choices, (dialog, which) -> {
                    if (which == 0) toast("Report submitted in demo mode.");
                    else if (which == 1) {
                        prefs.edit().putBoolean("blocked_" + username, true).apply();
                        toast("User blocked in demo mode.");
                    }
                })
                .show();
    }

    private void showEditProfile() {
        setupRoot();
        header("Edit profile", "Your changes are saved on this device.");
        EditText name = field("Display name");
        EditText bio = field("Bio");
        name.setText(prefs.getString("name_" + currentUser, currentUser));
        bio.setText(prefs.getString("bio_" + currentUser, ""));
        root.addView(name); root.addView(bio);
        root.addView(action("Save changes", v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 2) {
                toast("Display name is too short.");
                return;
            }
            prefs.edit().putString("name_" + currentUser, n)
                    .putString("bio_" + currentUser, bio.getText().toString().trim()).apply();
            toast("Profile updated.");
            showProfile(currentUser);
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void showInterests() {
        setupRoot();
        header("Your interests", "Choose up to 8 interests.");
        final Set<String> selected = new HashSet<>(selectedInterests);
        String[] choices = {"Music", "Gaming", "Football", "Movies", "Art", "Tech", "Books", "Travel",
                "Photography", "Fashion", "Fitness", "Coding"};
        LinearLayout list = verticalContent();
        for (String choice : choices) {
            CheckBox box = new CheckBox(this);
            box.setText(choice);
            box.setTextColor(Color.WHITE);
            box.setTextSize(16);
            box.setChecked(selected.contains(choice));
            final String interest = choice;
            box.setOnCheckedChangeListener((buttonView, checked) -> {
                if (checked) {
                    if (selected.size() >= 8) {
                        buttonView.setChecked(false);
                        toast("You can choose up to 8 interests.");
                    } else selected.add(interest);
                } else selected.remove(interest);
            });
            list.addView(box);
        }
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("Save interests", v -> {
            selectedInterests.clear();
            selectedInterests.addAll(selected);
            saveInterests();
            toast("Interests saved.");
            showHome();
        }));
        root.addView(action("← Back", v -> showHome()));
    }

    private void loadInterests() {
        selectedInterests.clear();
        String raw = prefs.getString("interests_" + currentUser, "");
        if (!raw.isEmpty()) selectedInterests.addAll(Arrays.asList(raw.split("\\|")));
    }

    private void saveInterests() {
        StringBuilder raw = new StringBuilder();
        for (String item : selectedInterests) {
            if (raw.length() > 0) raw.append('|');
            raw.append(item);
        }
        prefs.edit().putString("interests_" + currentUser, raw.toString()).apply();
    }

    private void showConnections() {
        setupRoot();
        header("Connections", "People you've connected with.");
        LinearLayout list = verticalContent();
        boolean found = false;
        for (int i = 0; i < demoUsers.length; i++) {
            if (prefs.getBoolean("connected_" + demoUsers[i], false)) {
                addPerson(list, demoNames[i], demoUsers[i]);
                found = true;
            }
        }
        if (!found) list.addView(label("No connections yet. Try Discover.", 15, false));
        root.addView(scroll(list), new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(action("← Back", v -> showHome()));
    }

    private void showMessages() {
        setupRoot();
        header("Messages", "Your conversations");
        TextView info = label("Messaging is prepared in this version as a local demo. Online messages will require a backend such as Supabase.", 15, false);
        info.setTextColor(Color.rgb(195, 195, 205));
        root.addView(info);
        gap(10);
        root.addView(action("← Back", v -> showHome()));
    }
}
